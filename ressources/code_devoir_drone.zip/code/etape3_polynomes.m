%% ÉTAPE 3 — Trajectoires polynomiales : minimum d'accélération, de jerk, de snap
% (TD 8.4b : w_d dépend du jerk, M_d du snap)
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();

% Quatre points de passage, segments de durées différentes
W = [0 0 1; 2 1.5 1.5; 4 0 2; 6 -1 1.5];
durees = [2 1 3];

%% 1. Même trajet, quatre critères
fprintf('\n--- Polynômes par morceaux, durées [%s] s ---\n', sprintf('%g ', durees));
fprintf('%-14s %6s %9s %9s %9s %9s %10s\n', 'critère', 'degré', '|a| max', '|j| max', 'saut v', 'saut a', 'saut jerk');
critere = {'vitesse', 'accélération', 'jerk', 'snap'};
dt = 1e-3;
t = (0:dt:sum(durees))';
traj = cell(4, 1);  A = cell(4, 1);  Jk = cell(4, 1);
for k = 1:4
    traj{k} = traj_polynomiale(W, durees, k);
    A{k} = zeros(numel(t), 3);  Jk{k} = zeros(numel(t), 3);
    for i = 1:numel(t)
        ref = eval_traj_polynomiale(traj{k}, t(i));
        A{k}(i, :) = ref.a';  Jk{k}(i, :) = ref.j';
    end
    % sauts de l'accélération et du jerk aux points intérieurs
    sauts = zeros(3, 1);
    for p = 2:numel(durees)
        tp = traj{k}.temps(p);
        avant = eval_traj_polynomiale(traj{k}, tp - 1e-9);
        apres = eval_traj_polynomiale(traj{k}, tp + 1e-9);
        sauts(1) = max(sauts(1), norm(apres.v - avant.v));
        sauts(2) = max(sauts(2), norm(apres.a - avant.a));
        sauts(3) = max(sauts(3), norm(apres.j - avant.j));
    end
    fprintf('%-14s %6d %9.2f %9.2f %9.2f %9.2f %10.2f\n', critere{k}, 2*k - 1, ...
            max(vecnorm(A{k}, 2, 2)), max(vecnorm(Jk{k}, 2, 2)), sauts);
end

%% 2. Ce que le drone en pense : suivi des trajectoires k = 2, 3, 4
G = gains_commande('regle');
opts.duree = sum(durees) + 1.5;
fprintf('\n--- Suivi par la commande en cascade (gains réglés) ---\n');
fprintf('%-14s %12s %22s %16s\n', 'critère', 'erreur max', 'saut de Omega en 1 ms', 'temps saturé (%)');
for k = 2:4
    consigne = @(tt) eval_traj_polynomiale(traj{k}, tt);
    res = simuler(P, G, consigne, @commande_cascade, opts);
    dOm = max(abs(diff(res.Omega)), [], 'all');      % plus grand saut d'un pas à l'autre
    fprintf('%-14s %11.3f m %15.0f tr/min %15.1f\n', critere{k}, res.erreur_max, dOm, 100*mean(res.sature));
end

if ~MODE_TEST
    figure('Name', 'Étape 3 - polynômes', 'Color', 'w');
    coul = lines(4);
    for k = 1:4
        X = zeros(numel(t), 3);
        for i = 1:numel(t), ref = eval_traj_polynomiale(traj{k}, t(i)); X(i, :) = ref.r'; end
        subplot(2, 2, 1); plot(X(:, 1), X(:, 2), 'Color', coul(k, :), 'LineWidth', 1.3); hold on;
        subplot(2, 2, 2); plot(t, A{k}(:, 1), 'Color', coul(k, :), 'LineWidth', 1.1); hold on;
        subplot(2, 2, 3); plot(t, Jk{k}(:, 1), 'Color', coul(k, :), 'LineWidth', 1.1); hold on;
    end
    subplot(2, 2, 1); plot(W(:, 1), W(:, 2), 'ko', 'MarkerFaceColor', 'k'); axis equal; grid on;
    xlabel('x'); ylabel('y'); legend(critere{:}, 'points', 'Location', 'best'); title('vue de dessus');
    subplot(2, 2, 2); grid on; xlabel('t (s)'); ylabel('a_x (m/s^2)');
    subplot(2, 2, 3); grid on; xlabel('t (s)'); ylabel('jerk_x (m/s^3)'); ylim([-20 20]);
    subplot(2, 2, 4); res = simuler(P, G, @(tt) eval_traj_polynomiale(traj{4}, tt), @commande_cascade, opts);
    plot(res.t, res.Omega); grid on; xlabel('t (s)'); ylabel('\Omega_i (tr/min)'); title('min. snap');
end
