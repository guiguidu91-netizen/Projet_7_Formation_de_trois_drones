function X0 = etat_initial(r0, psi0)
%ETAT_INITIAL  État de départ : drone immobile, à plat, en r0 avec un lacet psi0.
%   X0 = etat_initial(r0, psi0)    (psi0 = 0 par défaut)
%   X = [r; q; v; w] (voir dynamique_drone.m).
if nargin < 2, psi0 = 0; end
q0 = rot_vers_quat(rotation_zyx(0, 0, psi0));
X0 = [r0(:); q0; zeros(3,1); zeros(3,1)];
end
