function [Omega, U_reel, sature] = melangeur_inverse(U, P)
%MELANGEUR_INVERSE  Allocation : vitesses des rotors pour un torseur U (TD 3.2).
%
%   [Omega, U_reel, sature] = melangeur_inverse(U, P)
%   U      : torseur demandé [U1; U2; U3; U4] = [T; Mx; My; Mz]
%   Omega  : vitesses des rotors (tr/min), 4x1
%   U_reel : torseur réellement produit après saturation
%   sature : true si au moins un rotor est en butée
%
%   s = B^-1 U, puis chaque Omega_i^2 est ramené dans [0, Omega_max^2]
%   (question 3.2c). Cette saturation composante par composante déforme le
%   torseur : U_reel peut différer de U. Le mélangeur ne crée aucune
%   stabilité, il traduit seulement la demande de la commande.

s = P.Binv*U(:);
s_sat = min(max(s, 0), P.Omega_max^2);
sature = any(abs(s_sat - s) > 1e-9);
Omega  = sqrt(s_sat);
U_reel = P.B*s_sat;
end
