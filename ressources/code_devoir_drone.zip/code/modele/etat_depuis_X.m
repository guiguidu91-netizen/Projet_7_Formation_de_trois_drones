function etat = etat_depuis_X(X)
%ETAT_DEPUIS_X  Grandeurs utiles à la commande, calculées à partir de X.
%   etat.r    position r_oG^o
%   etat.R    attitude R_o^b
%   etat.eps  angles Z-Y-X [phi; theta; psi]
%   etat.v_b  vitesse dans R_b,   etat.dr = R*v_b vitesse dans R_o (= r point)
%   etat.w    vitesse angulaire w_ob^b
etat.r   = X(1:3);
etat.R   = quat_vers_rot(X(4:7));
etat.eps = angles_zyx(etat.R);
etat.v_b = X(8:10);
etat.dr  = etat.R*etat.v_b;
etat.w   = X(11:13);
end
