function res = simuler(P, G, consigne, loi, opts)
%SIMULER  Simulation en boucle fermée : consigne -> commande -> mélangeur -> drone.
%
%   res = simuler(P, G, consigne, loi, opts)
%   P        : paramètres (parametres_drone)
%   G        : gains (gains_commande)
%   consigne : fonction t -> ref (ex. @(t) traj_helice(t, 5, 2.5, 12))
%   loi      : @commande_cascade ou @commande_geometrique
%   opts     : structure facultative
%       .duree     durée simulée (s)                       défaut 10
%       .dt        pas d'intégration et de commande (s)    défaut 1e-3 (1 kHz)
%       .X0        état initial                            défaut : immobile sur la consigne à t = 0
%       .F_ext_o   force extérieure dans R_o (N), vecteur ou fonction de t (vent)
%       .ecart_max erreur de position (m) au-delà de laquelle on arrête   défaut 5
%
%   À chaque pas : on lit l'état, on calcule U, le mélangeur inverse donne
%   les Omega_i (saturés), puis on intègre le modèle complet sur dt.
%
%   res : t, r, r_ref, r_T, dr, eps, eps_d, Omega, U, sature, e (erreur
%         utilisée par la commande), inclinaison, plus des indicateurs :
%         erreur_max, erreur_rms (|r - r_ref|), inclinaison_max (deg),
%         diverge (true/false).

if nargin < 5, opts = struct(); end
if ~isfield(opts, 'duree'),     opts.duree = 10;      end
if ~isfield(opts, 'dt'),        opts.dt = 1e-3;       end
if ~isfield(opts, 'ecart_max'), opts.ecart_max = 5;   end
if ~isfield(opts, 'F_ext_o'),   opts.F_ext_o = zeros(3,1); end
ref0 = consigne(0);
if ~isfield(opts, 'X0'), opts.X0 = etat_initial(ref0.r, ref0.psi); end

dt = opts.dt;
N  = floor(opts.duree/dt) + 1;
res.t = (0:N-1)'*dt;
[res.r, res.r_ref, res.r_T, res.dr, res.eps, res.eps_d, res.e] = deal(zeros(N, 3));
[res.Omega, res.U] = deal(zeros(N, 4));
res.sature = false(N, 1);
res.inclinaison = zeros(N, 1);
res.diverge = false;

X   = opts.X0;
mem = memoire_commande();
n_fin = N;
for k = 1:N
    t    = res.t(k);
    etat = etat_depuis_X(X);
    ref  = consigne(t);

    [U, info, mem] = loi(etat, ref, P, G, mem, dt);
    [Omega, ~, sat] = melangeur_inverse(U, P);

    res.r(k,:)     = etat.r';
    res.dr(k,:)    = etat.dr';
    res.eps(k,:)   = etat.eps';
    res.r_ref(k,:) = ref.r';
    res.r_T(k,:)   = info.r_T';
    res.eps_d(k,:) = info.eps_d';
    res.e(k,:)     = info.e';
    res.U(k,:)     = U';
    res.Omega(k,:) = Omega';
    res.sature(k)  = sat;
    res.inclinaison(k) = acosd(max(-1, min(1, etat.R(3,3))));

    if any(~isfinite(X)) || norm(info.e) > opts.ecart_max
        res.diverge = true;
        n_fin = k;
        break
    end

    if isa(opts.F_ext_o, 'function_handle')
        F = opts.F_ext_o(t);
    else
        F = opts.F_ext_o;
    end
    X = pas_rk4(X, Omega, P, dt, F(:));
end

% on coupe les tableaux si la simulation s'est arrêtée avant la fin
champs = {'t','r','r_ref','r_T','dr','eps','eps_d','e','Omega','U','sature','inclinaison'};
for c = 1:numel(champs)
    res.(champs{c}) = res.(champs{c})(1:n_fin, :);
end
err = vecnorm(res.r - res.r_ref, 2, 2);
res.erreur_max = max(err);
res.erreur_rms = sqrt(mean(err.^2));
res.inclinaison_max = max(res.inclinaison);
res.P = P;
end
