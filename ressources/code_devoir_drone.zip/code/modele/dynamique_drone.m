function dX = dynamique_drone(X, Omega, P, F_ext_o, M_ext_b)
%DYNAMIQUE_DRONE  Modèle non linéaire complet du quadrirotor (TD question 4.1).
%
%   dX = dynamique_drone(X, Omega, P)
%   dX = dynamique_drone(X, Omega, P, F_ext_o, M_ext_b)
%
%   État (13 composantes) :
%       X = [ r ; q ; v ; w ]
%       r = r_oG^o  position de G dans R_o           (3)
%       q = [q0; q_v] quaternion unitaire de R_o^b    (4)
%       v = v_oG^b  vitesse de G exprimée dans R_b    (3)
%       w = w_ob^b  vitesse angulaire dans R_b        (3)
%   Entrée : Omega (4x1) vitesses des rotors en tr/min.
%   Perturbations optionnelles : force F_ext_o exprimée dans R_o (vent),
%   moment M_ext_b exprimé dans R_b.
%
%   Équations (corrigé 4.1) :
%       r'          = R v                                  (fermeture cinématique)
%       R'          = R S(w)      <=>  q' = 1/2 q (x) [0; w]
%       m(v' + w^v) = m R' g^o + U1 e3 - Dv v + F_ext^b
%       J w' + w^Jw = [U2;U3;U4] - Dw w + M_ext^b - w ^ (h_r e3)
%   avec U = B*Omega.^2 (mélangeur direct) et h_r = Jr*Omega_Sigma.
%   Le terme de réaction -Jr*dOmega_Sigma/dt e3 est négligé (pas de
%   dynamique moteur dans ce modèle : les rotors suivent instantanément).

if nargin < 4 || isempty(F_ext_o), F_ext_o = zeros(3,1); end
if nargin < 5 || isempty(M_ext_b), M_ext_b = zeros(3,1); end

r = X(1:3);  q = X(4:7);  v = X(8:10);  w = X(11:13);
q = q/norm(q);
R = quat_vers_rot(q);                 % R_o^b
e3  = [0; 0; 1];
g_o = [0; 0; -P.g];

% --- torseur propulsif par le mélangeur direct (question 3.1) ---
U  = P.B*(Omega(:).^2);
U1 = U(1);
M  = U(2:4);

% --- effet gyroscopique des rotors (question 2.5), Omega en rad/s ---
Omega_Sigma = P.epsilon*Omega(:)*pi/30;
h_r = P.Jr*Omega_Sigma;

% --- fermetures cinématiques ---
dr = R*v;
dq = 0.5*quat_produit(q, [0; w]);

% --- Newton-Euler en G, dans R_b ---
F_b = U1*e3 - P.Dv*v + R'*F_ext_o;
dv  = -cross(w, v) + R'*g_o + F_b/P.m;
dw  = P.J \ (M - P.Dw*w + M_ext_b - cross(w, P.J*w) - cross(w, h_r*e3));

dX = [dr; dq; dv; dw];
end
