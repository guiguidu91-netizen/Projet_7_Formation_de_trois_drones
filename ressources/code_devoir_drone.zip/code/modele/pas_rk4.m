function X = pas_rk4(X, Omega, P, dt, F_ext_o)
%PAS_RK4  Un pas de Runge-Kutta d'ordre 4, vitesses des rotors bloquées sur le pas.
%   X = pas_rk4(X, Omega, P, dt, F_ext_o)
%   Le quaternion est renormalisé à la fin du pas (contrainte |q| = 1).
if nargin < 5, F_ext_o = zeros(3,1); end
k1 = dynamique_drone(X,           Omega, P, F_ext_o);
k2 = dynamique_drone(X + dt/2*k1, Omega, P, F_ext_o);
k3 = dynamique_drone(X + dt/2*k2, Omega, P, F_ext_o);
k4 = dynamique_drone(X + dt*k3,   Omega, P, F_ext_o);
X = X + dt/6*(k1 + 2*k2 + 2*k3 + k4);
X(4:7) = X(4:7)/norm(X(4:7));
end
