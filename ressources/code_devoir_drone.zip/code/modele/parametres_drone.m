function P = parametres_drone()
%PARAMETRES_DRONE  Paramètres du quadrirotor en X (valeurs numériques du TD).
%
%   P = parametres_drone()
%
%   Conventions du TD : repère inertiel R_o en ENU (k vers le haut), repère
%   corps R_b en FLU (avant, gauche, haut), origine en G. Les vitesses de
%   rotation des rotors Omega_i sont en tr/min, comme k_f et k_m du TD.
%
%   Géométrie X (TD question 2) :
%       rotor 1 avant-gauche  r_1 = [ a  a 0]   sigma_1 = +1 (horaire)
%       rotor 2 arrière-gauche r_2 = [-a  a 0]   sigma_2 = -1 (trigo)
%       rotor 3 arrière-droit  r_3 = [-a -a 0]   sigma_3 = +1 (horaire)
%       rotor 4 avant-droit    r_4 = [ a -a 0]   sigma_4 = -1 (trigo)
%   avec a = l/sqrt(2).
%
%   Toute la géométrie est contenue dans P.r_rotors et P.sigma : la matrice
%   du mélangeur P.B en est déduite par matrice_melangeur.m. Pour étudier
%   une autre architecture (drone en +, hexarotor...), il suffit de changer
%   ces deux champs.

% --- masse, inertie, pesanteur (tableau « valeurs numériques ») ---
P.g = 9.81;                                  % m/s^2
P.m = 0.18;                                  % kg
P.J = diag([2.50e-4, 2.32e-4, 3.74e-4]);     % J = diag(Ix, Iy, Iz), kg.m^2

% --- hélices : f_i = kf*Omega_i^2 , tau_i = km*Omega_i^2 (Omega en tr/min) ---
P.kf = 6.11e-8;                              % N/(tr/min)^2
P.km = 1.5e-9;                               % N.m/(tr/min)^2

% --- géométrie X ---
P.l = 0.086;                                 % distance rotor - G (m)
P.a = P.l/sqrt(2);                           % projection sur les axes corps
a = P.a;
P.r_rotors = [ a  -a  -a   a ;               % colonne i = r_i dans R_b
               a   a  -a  -a ;
               0   0   0   0 ];
P.sigma   = [+1 -1 +1 -1];                   % signe du couple de réaction
P.epsilon = -P.sigma;                        % sens de rotation (+1 = trigo)

% --- mélangeur direct U = B*s, s = Omega.^2 (question 3) ---
P.B    = matrice_melangeur(P);
P.Binv = inv(P.B);

% --- limites des moteurs : poussée totale entre 0 et 2mg ---
P.f_max     = 2*P.m*P.g/4;                   % poussée max par rotor (N)
P.Omega_max = sqrt(P.f_max/P.kf);            % tr/min

% --- termes secondaires du modèle complet (question 4.1), nuls par défaut ---
P.Dv = 0;            % traînée linéaire du châssis en translation
P.Dw = 0;            % traînée linéaire du châssis en rotation
P.Jr = 0;            % inertie rotor + hélice (kg.m^2), ex. 1e-6 pour tester
end
