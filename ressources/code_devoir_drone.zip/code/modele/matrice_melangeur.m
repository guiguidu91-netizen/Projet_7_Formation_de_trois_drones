function B = matrice_melangeur(P)
%MATRICE_MELANGEUR  Mélangeur direct U = B*s (TD question 3.1).
%
%   B = matrice_melangeur(P)
%   U = [U1 U2 U3 U4]' = [T Mx My Mz]'   et   s = [Omega_1^2 ... Omega_4^2]'
%
%   La colonne j de B est le torseur produit en G par le seul rotor j
%   tournant à Omega_j^2 = 1 :
%     - poussée          k_f * k_b
%     - moment en G      r_j ^ (k_f k_b) = k_f [ r_jy ; -r_jx ; 0 ]
%     - couple de lacet  sigma_j * k_m
%   Configuration X : on doit retrouver la matrice du corrigé (3.1).

n = size(P.r_rotors, 2);
B = zeros(4, n);
for j = 1:n
    rj = P.r_rotors(:, j);
    B(:, j) = [ P.kf ;
                P.kf*rj(2) ;
               -P.kf*rj(1) ;
                P.sigma(j)*P.km ];
end
end
