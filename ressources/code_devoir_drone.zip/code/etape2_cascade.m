%% ÉTAPE 2 — Commande en cascade et réglage des gains (TD question 5)
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();

%% 1. Pulsation propre et amortissement de chaque boucle (5.4b)
G_td = gains_commande('td');
G_am = gains_commande('amorti');
G_rg = gains_commande('regle');
noms = {'x', 'y', 'z', 'roulis', 'tangage', 'lacet'};
kp = [G_td.kp; G_td.kp_att];   kd = [G_td.kd; G_td.kd_att];
wn = sqrt(kp);  zeta = kd./(2*wn);
D  = 100*exp(-pi*zeta./sqrt(1 - zeta.^2));          % dépassement d'un 2e ordre
fprintf('\n--- Gains du TD (5.4b) ---\n%-8s %6s %6s %8s %6s %8s\n', 'boucle', 'kp', 'kd', 'wn', 'zeta', 'D (%)');
for i = 1:6
    fprintf('%-8s %6.0f %6.1f %8.2f %6.2f %8.0f\n', noms{i}, kp(i), kd(i), wn(i), zeta(i), D(i));
end
fprintf('Séparation des échelles de temps : wn(roulis)/wn(x) = %.1f\n', wn(4)/wn(1));
fprintf('Cascade P-P équivalente (5.4a) en x : k_v = kd = %.0f, k_r = kp/kd = %.0f\n', ...
        G_td.kd(1), G_td.kp(1)/G_td.kd(1));

%% 2. Échelon de 1 m en x (et 0,5 m en z) : trois jeux de gains
%   TD      : gains de la question 5.4(b)
%   amorti  : kd d'attitude porté à zeta = 0,7, kp inchangé (piste du corrigé 5.4)
%   réglé   : attitude plus rapide (wn = 30 rad/s) ET position amortie (zeta = 0,7)
consigne = @(t) traj_echelon(t, [0 0 1], [1 0 1.5], 1);
opts.duree = 7;
jeux = {G_td, 'gains TD'; G_am, 'attitude amortie'; G_rg, 'réglé'};
fprintf('\n--- Échelon x : 0 -> 1 m, z : 1 -> 1,5 m ---\n');
fprintf('%-18s %8s %9s %8s %8s %10s %10s %8s\n', 'jeu', 'kR', 'kR/wn_x', 'Dx (%)', 'Dz (%)', 'tr5%x (s)', 'theta max', 'saturé');
res_e = cell(3, 1);
for j = 1:3
    res = simuler(P, jeux{j, 1}, consigne, @commande_cascade, opts);
    res_e{j} = res;
    x = res.r(:, 1);  z = res.r(:, 3);
    Dx = 100*(max(x) - 1);  Dz = 100*(max(z) - 1.5)/0.5;
    hors = find(abs(x - 1) > 0.05, 1, 'last');
    tr = res.t(hors) - 1;
    kR = jeux{j, 1}.kp_att(2)/jeux{j, 1}.kd_att(2);          % gain de la boucle d'attitude (tangage)
    wn_x = sqrt(jeux{j, 1}.kp(1));
    fprintf('%-18s %8.1f %9.1f %8.1f %8.1f %10.2f %9.1f° %7.0f%%\n', jeux{j, 2}, kR, kR/wn_x, Dx, Dz, tr, ...
            max(abs(rad2deg(res.eps(:, 2)))), 100*mean(res.sature));
end

%% 3. Vent constant : intérêt du terme intégral (5.2)
F_vent = [0.1; 0; 0];                       % 0,1 N selon x
consigne0 = @(t) consigne_fixe([0 0 1]);
opts_v.duree = 15;  opts_v.F_ext_o = F_vent;
G_sans = G_rg;
G_avec = G_rg;  G_avec.ki = [3; 3; 20];
r_sans = simuler(P, G_sans, consigne0, @commande_cascade, opts_v);
r_avec = simuler(P, G_avec, consigne0, @commande_cascade, opts_v);
fprintf('\n--- Vent de %.2f N selon x ---\n', F_vent(1));
fprintf('Erreur finale en x sans intégrale : %.3f m (prévision F/(m kp) = %.3f m)\n', ...
        r_sans.r(end, 1), F_vent(1)/(P.m*G_rg.kp(1)));
fprintf('Erreur finale en x avec intégrale : %.4f m\n', r_avec.r(end, 1));
fprintf('Inclinaison finale (theta) : %.2f deg (prévision atan(F/mg) = %.2f deg)\n', ...
        rad2deg(r_avec.eps(end, 2)), -atand(F_vent(1)/(P.m*P.g)));

if ~MODE_TEST
    figure('Name', 'Étape 2 - échelon', 'Color', 'w');
    subplot(2, 1, 1);
    plot(res_e{1}.t, res_e{1}.r(:, 1), res_e{2}.t, res_e{2}.r(:, 1), res_e{3}.t, res_e{3}.r(:, 1), ...
         res_e{1}.t, res_e{1}.r_ref(:, 1), 'k--');
    grid on; ylabel('x (m)'); legend(jeux{:, 2}, 'consigne');
    subplot(2, 1, 2);
    plot(res_e{1}.t, rad2deg(res_e{1}.eps(:, 2)), res_e{2}.t, rad2deg(res_e{2}.eps(:, 2)), ...
         res_e{3}.t, rad2deg(res_e{3}.eps(:, 2)));
    grid on; xlabel('t (s)'); ylabel('\theta (deg)');
    tracer_simulation(res_e{1}, 'Échelon, gains du TD');
    tracer_simulation(res_e{3}, 'Échelon, gains réglés');
    animer_drone(res_e{1}, struct('echelle', 3));
end
