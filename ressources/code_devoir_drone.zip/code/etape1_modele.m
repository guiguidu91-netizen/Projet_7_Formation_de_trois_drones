%% ÉTAPE 1 — Modèle du drone X, mélangeur et vol stationnaire (TD questions 2 à 4)
% Ce script ne contient aucune commande : on vérifie le modèle seul.
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();

%% 1. Mélangeur direct (question 3.1)
fprintf('\n--- Mélangeur direct B (U = B s), configuration X ---\n');
disp(P.B);
D = P.B*P.B';
fprintf('Termes hors diagonale de B*B'' : %.1e (lignes orthogonales, 3.2a)\n', ...
        max(abs(D - diag(diag(D))), [], 'all'));
fprintf('Écart relatif entre inv(B) et B''*inv(D) : %.1e\n', ...
        norm(P.Binv - P.B'/D)/norm(P.Binv));

%% 2. Vol stationnaire (question 4.3)
Omega_h = sqrt(P.m*P.g/(4*P.kf));
[Om, Ur] = melangeur_inverse([P.m*P.g; 0; 0; 0], P);
fprintf('\n--- Vol stationnaire ---\n');
fprintf('Omega* = %.0f tr/min (formule), mélangeur inverse : [%s] tr/min\n', ...
        Omega_h, sprintf('%.0f ', Om));
fprintf('Omega_max = %.0f tr/min (poussée totale 2mg)\n', P.Omega_max);

%% 3. Trois expériences en boucle ouverte (questions 2.3b et 4.2c)
% On part du hover et on déséquilibre les rotors de 1 % pendant 0,25 s.
% Chaque ligne : facteurs multiplicatifs des 4 vitesses de rotation.
essais = { 'arrière plus vite (2,3)',  [0.99 1.01 1.01 0.99] ;
           'gauche plus vite (1,2)',   [1.01 1.01 0.99 0.99] ;
           'horaires plus vite (1,3)', [1.01 0.99 1.01 0.99] };
dt = 1e-3;  T = 0.25;  N = round(T/dt);
fprintf('\n--- Boucle ouverte, %.2f s après le déséquilibre ---\n', T);
fprintf('%-26s %8s %8s %8s %9s %9s\n', 'essai', 'phi', 'theta', 'psi', 'x (mm)', 'y (mm)');
traces = cell(size(essais, 1), 1);
for e = 1:size(essais, 1)
    X = etat_initial([0 0 1]);
    Omega = Omega_h*essais{e, 2}(:);
    hist = zeros(N, 6);
    for k = 1:N
        X = pas_rk4(X, Omega, P, dt);
        et = etat_depuis_X(X);
        hist(k, :) = [rad2deg(et.eps') et.r'];
    end
    traces{e} = hist;
    fprintf('%-26s %7.1f° %7.1f° %7.1f° %9.1f %9.1f\n', essais{e, 1}, hist(end, 1:3), 1000*hist(end, 4:5));
end

if ~MODE_TEST
    figure('Name', 'Étape 1 - boucle ouverte', 'Color', 'w');
    t = (1:N)'*dt;
    for e = 1:3
        subplot(1, 3, e);
        plot(t, traces{e}(:, 1:3), 'LineWidth', 1.2); grid on;
        xlabel('t (s)'); ylabel('angles (deg)'); title(essais{e, 1});
        legend('\phi', '\theta', '\psi', 'Location', 'northwest');
    end
end
