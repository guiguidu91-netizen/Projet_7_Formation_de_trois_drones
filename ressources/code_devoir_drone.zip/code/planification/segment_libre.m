function ok = segment_libre(carte, p1, p2)
%SEGMENT_LIBRE  true si le segment [p1, p2] ne touche aucun obstacle.
%   On teste des points espacés de moins d'un quart de cellule.
d = norm(p2 - p1);
n = max(2, ceil(d/(0.25*min(carte.resolution))) + 1);
s = linspace(0, 1, n)';
ok = all(point_libre(carte, p1 + s.*(p2 - p1)));
end
