function carte = charger_carte(fichier, resolution, marge)
%CHARGER_CARTE  Lit une carte d'obstacles et construit la grille d'occupation.
%
%   carte = charger_carte(fichier, resolution, marge)
%   fichier    : texte avec des lignes
%                  limites xmin ymin zmin xmax ymax zmax
%                  bloc    xmin ymin zmin xmax ymax zmax R G B
%   resolution : [dxy dz] taille d'une cellule (m)
%   marge      : distance de sécurité (m) ajoutée autour des blocs
%                (le drone n'est pas un point)
%
%   carte.limites, carte.blocs, carte.resolution, carte.marge,
%   carte.dims (nombre de cellules en x, y, z), carte.occupe (grille logique).

if ~isfile(fichier)          % nom seul : on cherche dans le dossier cartes/
    fichier = fullfile(fileparts(mfilename('fullpath')), 'cartes', fichier);
end
texte = fileread(fichier);
lignes = regexp(texte, '\r?\n', 'split');
carte.limites = [];
carte.blocs = zeros(0, 9);
for i = 1:numel(lignes)
    l = strtrim(lignes{i});
    if isempty(l) || l(1) == '#', continue; end
    mots = strsplit(l);
    valeurs = str2double(mots(2:end));
    switch lower(mots{1})
        case 'limites', carte.limites = valeurs(1:6);
        case 'bloc'
            v = [valeurs, zeros(1, 9)];
            carte.blocs(end+1, :) = v(1:9);
    end
end
carte.resolution = [resolution(1) resolution(1) resolution(end)];
carte.marge = marge;
L = carte.limites;
carte.dims = max(1, floor((L(4:6) - L(1:3))./carte.resolution));

% une cellule est occupée si son centre est dans un bloc élargi de la marge
[ix, iy, iz] = ndgrid(1:carte.dims(1), 1:carte.dims(2), 1:carte.dims(3));
centres = indice_vers_point(carte, [ix(:) iy(:) iz(:)]);
occ = false(size(centres, 1), 1);
for b = 1:size(carte.blocs, 1)
    B = carte.blocs(b, 1:6);
    dedans = all(centres >= B(1:3) - marge & centres <= B(4:6) + marge, 2);
    occ = occ | dedans;
end
carte.occupe = reshape(occ, carte.dims);
end
