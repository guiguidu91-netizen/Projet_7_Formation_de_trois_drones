function ok = point_libre(carte, p)
%POINT_LIBRE  true si les points p (une ligne par point) sont dans les limites
%   et hors de tous les blocs élargis de la marge (test exact, sans grille).
L = carte.limites;
ok = all(p >= L(1:3) & p <= L(4:6), 2);
for b = 1:size(carte.blocs, 1)
    B = carte.blocs(b, 1:6);
    ok = ok & ~all(p >= B(1:3) - carte.marge & p <= B(4:6) + carte.marge, 2);
end
end
