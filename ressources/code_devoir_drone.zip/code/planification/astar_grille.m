function [chemin, n_explores] = astar_grille(carte, depart, arrivee, methode)
%ASTAR_GRILLE  Plus court chemin sur la grille d'occupation (A*, 6 voisins).
%
%   [chemin, n_explores] = astar_grille(carte, depart, arrivee)
%   [chemin, n_explores] = astar_grille(carte, depart, arrivee, 'dijkstra')
%   depart, arrivee : points [x y z] (m)
%   chemin          : suite de points [x y z] (une ligne par cellule),
%                     commençant par depart et finissant par arrivee ;
%                     vide si aucun chemin n'existe
%   n_explores      : nombre de cellules sorties de la liste ouverte
%
%   Coût d'un pas : distance entre centres de cellules. Heuristique :
%   distance euclidienne jusqu'à l'arrivée (jamais supérieure au vrai coût,
%   donc A* rend le plus court chemin de la grille). Avec 'dijkstra',
%   l'heuristique est nulle : c'est l'algorithme de Dijkstra.

if nargin < 4, methode = 'astar'; end
avec_h = ~strcmpi(methode, 'dijkstra');

dims = carte.dims;
nc   = prod(dims);
id = point_vers_indice(carte, [depart(:)'; arrivee(:)']);
s  = sub2ind(dims, id(1,1), id(1,2), id(1,3));
c  = sub2ind(dims, id(2,1), id(2,2), id(2,3));
if carte.occupe(s) || carte.occupe(c)
    error('astar_grille:occupe', 'Le départ ou l''arrivée est dans un obstacle.');
end

pc = indice_vers_point(carte, id(2,:));          % centre de la cellule d'arrivée
h  = @(k) heuristique(k);
g  = inf(nc, 1);   g(s) = 0;
parent = zeros(nc, 1, 'uint32');
ferme  = false(nc, 1);
ouverts = s;  f_ouverts = h(s);
voisins = [1 0 0; -1 0 0; 0 1 0; 0 -1 0; 0 0 1; 0 0 -1];
cout_pas = abs(voisins)*carte.resolution';
n_explores = 0;

while ~isempty(ouverts)
    [~, m] = min(f_ouverts);
    u = ouverts(m);
    ouverts(m) = [];  f_ouverts(m) = [];
    if ferme(u), continue; end
    ferme(u) = true;
    n_explores = n_explores + 1;
    if u == c, break; end
    [i, j, k] = ind2sub(dims, u);
    for v = 1:6
        n = [i j k] + voisins(v, :);
        if any(n < 1) || any(n > dims), continue; end
        w = sub2ind(dims, n(1), n(2), n(3));
        if carte.occupe(w) || ferme(w), continue; end
        gw = g(u) + cout_pas(v);
        if gw < g(w)
            g(w) = gw;
            parent(w) = u;
            ouverts(end+1) = w;              %#ok<AGROW>
            f_ouverts(end+1) = gw + h(w);    %#ok<AGROW>
        end
    end
end

if ~ferme(c)
    chemin = zeros(0, 3);
    return
end
% remontée des parents
liste = c;
while liste(end) ~= s
    liste(end+1) = parent(liste(end)); %#ok<AGROW>
end
liste = flipud(liste(:));
[i, j, k] = ind2sub(dims, liste);
chemin = indice_vers_point(carte, [i j k]);
chemin(1, :) = depart(:)';
chemin(end, :) = arrivee(:)';

    function d = heuristique(kk)
        [a1, a2, a3] = ind2sub(dims, kk);
        if avec_h
            d = norm(indice_vers_point(carte, [a1 a2 a3]) - pc);
        else
            d = 0;
        end
    end
end
