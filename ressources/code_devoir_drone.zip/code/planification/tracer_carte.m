function tracer_carte(carte, ax)
%TRACER_CARTE  Dessine les blocs de la carte (parallélépipèdes semi-transparents).
if nargin < 2, ax = gca; end
hold(ax, 'on');
faces = [1 2 3 4; 5 6 7 8; 1 2 6 5; 2 3 7 6; 3 4 8 7; 4 1 5 8];
for b = 1:size(carte.blocs, 1)
    B = carte.blocs(b, :);
    x = B([1 4 4 1 1 4 4 1]);  y = B([2 2 5 5 2 2 5 5]);  z = B([3 3 3 3 6 6 6 6]);
    coul = B(7:9)/255;
    if all(coul == 0), coul = [0.8 0.3 0.3]; end
    patch(ax, 'Vertices', [x' y' z'], 'Faces', faces, 'FaceColor', coul, ...
          'FaceAlpha', 0.25, 'EdgeColor', coul*0.6);
end
L = carte.limites;
axis(ax, [L(1) L(4) L(2) L(5) L(3) L(6)]);
axis(ax, 'equal'); grid(ax, 'on'); view(ax, 3);
xlabel(ax, 'x (m)'); ylabel(ax, 'y (m)'); zlabel(ax, 'z (m)');
end
