function p = indice_vers_point(carte, idx)
%INDICE_VERS_POINT  Centre (x,y,z) des cellules d'indices idx = [i j k] (une ligne par cellule).
p = carte.limites(1:3) + (idx - 0.5).*carte.resolution;
end
