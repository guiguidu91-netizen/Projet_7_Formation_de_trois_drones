function [traj, points, n_ajouts] = traj_sans_collision(carte, points, v_moy, k)
%TRAJ_SANS_COLLISION  Trajectoire polynomiale par les points, vérifiée contre les obstacles.
%
%   [traj, points, n_ajouts] = traj_sans_collision(carte, points, v_moy, k)
%   Les segments droits entre points sont libres, mais le polynôme peut
%   s'en écarter (il « arrondit » les coins). On échantillonne la
%   trajectoire ; si un échantillon tombe dans un obstacle, on ajoute le
%   milieu du segment fautif comme point de passage et on recommence.
%   La trajectoire a le droit d'entamer la moitié de la marge de sécurité
%   (jamais l'obstacle lui-même) : on teste avec carte.marge/2.
n_ajouts = 0;
carte_test = carte;  carte_test.marge = carte.marge/2;
for essai = 1:10
    durees = allouer_temps(points, v_moy);
    traj = traj_polynomiale(points, durees, k);
    t = 0:0.02:traj.temps(end);
    fautif = 0;
    for it = 1:numel(t)
        ref = eval_traj_polynomiale(traj, t(it));
        if ~point_libre(carte_test, ref.r')
            fautif = find(t(it) >= traj.temps(1:end-1), 1, 'last');
            break
        end
    end
    if fautif == 0, return; end
    milieu = 0.5*(points(fautif, :) + points(fautif+1, :));
    points = [points(1:fautif, :); milieu; points(fautif+1:end, :)];
    n_ajouts = n_ajouts + 1;
end
warning('traj_sans_collision:echec', 'Trajectoire encore en collision après 10 essais.');
end
