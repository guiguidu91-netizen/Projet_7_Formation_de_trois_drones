function durees = allouer_temps(points, v_moy)
%ALLOUER_TEMPS  Durée de chaque segment entre points de passage.
%   durees = allouer_temps(points, v_moy)
%   La durée d'un segment est proportionnelle à la racine de sa longueur :
%   un segment court reçoit relativement plus de temps (le drone doit y
%   accélérer puis freiner). Le total donne une vitesse moyenne v_moy.
L = vecnorm(diff(points), 2, 2)';
durees = sqrt(L);
durees = durees*sum(L)/(v_moy*sum(durees));
end
