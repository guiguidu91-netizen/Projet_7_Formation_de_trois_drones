function idx = point_vers_indice(carte, p)
%POINT_VERS_INDICE  Cellule [i j k] contenant chaque point p = [x y z] (une ligne par point).
idx = floor((p - carte.limites(1:3))./carte.resolution) + 1;
idx = max(1, min(idx, carte.dims));
end
