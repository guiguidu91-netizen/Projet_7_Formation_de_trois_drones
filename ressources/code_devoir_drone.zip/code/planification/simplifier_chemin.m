function points = simplifier_chemin(carte, chemin)
%SIMPLIFIER_CHEMIN  Garde seulement les points de passage utiles.
%   points = simplifier_chemin(carte, chemin)
%   Depuis le point courant, on saute au point le plus lointain du chemin
%   qu'on peut rejoindre en ligne droite sans toucher d'obstacle. Les
%   centaines de cellules de A* deviennent quelques points de passage.
points = chemin(1, :);
i = 1;
n = size(chemin, 1);
while i < n
    j = n;
    while j > i + 1 && ~segment_libre(carte, chemin(i,:), chemin(j,:))
        j = j - 1;
    end
    points(end+1, :) = chemin(j, :); %#ok<AGROW>
    i = j;
end
end
