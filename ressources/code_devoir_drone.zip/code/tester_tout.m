%TESTER_TOUT  Lance les six étapes sans figure et écrit le journal journal_tests.txt.
%   À utiliser pour vérifier une installation : chaque étape doit finir par OK.
racine = fileparts(mfilename('fullpath'));
run(fullfile(racine, 'demarrer.m'));
journal = fullfile(racine, 'journal_tests.txt');
if isfile(journal), delete(journal); end
diary(journal);
fprintf('MATLAB %s, %s\n', version, char(datetime('now')));
vis = get(0, 'DefaultFigureVisible');
set(0, 'DefaultFigureVisible', 'off');
etapes = {'etape1_modele', 'etape2_cascade', 'etape3_polynomes', ...
          'etape4_geometrique', 'etape5_chemin', 'etape6_planification'};
bilan = cell(numel(etapes), 1);
for n = 1:numel(etapes)
    fprintf('\n================ %s ================\n', etapes{n});
    tic;
    try
        lancer_etape(fullfile(racine, [etapes{n} '.m']));
        bilan{n} = sprintf('%-22s OK      %6.1f s', etapes{n}, toc);
    catch err
        bilan{n} = sprintf('%-22s ERREUR  %s', etapes{n}, err.message);
        fprintf(2, '%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    end
end
close all;
set(0, 'DefaultFigureVisible', vis);
fprintf('\n================ BILAN ================\n');
fprintf('%s\n', bilan{:});
diary off;

function lancer_etape(fichier)
% chaque étape tourne dans son propre espace de travail, en mode test
MODE_TEST = true; %#ok<NASGU>
run(fichier);
end
