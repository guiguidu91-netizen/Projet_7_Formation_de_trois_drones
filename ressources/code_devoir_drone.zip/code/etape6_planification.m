%% ÉTAPE 6 — De la carte aux rotors : planification puis suivi
% Chaîne complète : carte -> A* -> points de passage -> min. snap -> commande -> mélangeur
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();

carte   = charger_carte('carte1.txt', [0.25 0.25], 0.3);
depart  = [1 -4 1];
arrivee = [8 18 3];

tic;
[chemin, n_explores] = astar_grille(carte, depart, arrivee);
t_astar = toc;
tic;
[chemin_dij, n_dij] = astar_grille(carte, depart, arrivee, 'dijkstra');
t_dij = toc;
if isempty(chemin), error('Pas de chemin trouvé.'); end
L = sum(vecnorm(diff(chemin), 2, 2));
points = simplifier_chemin(carte, chemin);
[traj, points, n_ajouts] = traj_sans_collision(carte, points, 1.5, 4);

fprintf('\n--- Planification sur carte1 ---\n');
fprintf('Grille %d x %d x %d, %d cellules occupées sur %d\n', carte.dims, nnz(carte.occupe), numel(carte.occupe));
fprintf('A*       : %6d cellules explorées en %.2f s, chemin de %d cellules, longueur %.1f m\n', ...
        n_explores, t_astar, size(chemin, 1), L);
fprintf('Dijkstra : %6d cellules explorées en %.2f s, chemin de %d cellules, longueur %.1f m\n', ...
        n_dij, t_dij, size(chemin_dij, 1), sum(vecnorm(diff(chemin_dij), 2, 2)));
fprintf('Après simplification : %d points de passage (%d ajoutés contre les collisions)\n', ...
        size(points, 1), n_ajouts);
fprintf('Durée de la trajectoire min. snap : %.1f s\n', traj.temps(end));

G = gains_commande('regle');
consigne = @(t) eval_traj_polynomiale(traj, t);
res = simuler(P, G, consigne, @commande_geometrique, struct('duree', traj.temps(end) + 2));
libre = point_libre(struct('limites', carte.limites, 'blocs', carte.blocs, 'marge', 0), res.r);
fprintf('Suivi : erreur max %.3f m, inclinaison max %.1f deg, collision : %s\n', ...
        res.erreur_max, res.inclinaison_max, mat2str(any(~libre)));

if ~MODE_TEST
    figure('Name', 'Étape 6 - planification', 'Color', 'w');
    ax = axes; tracer_carte(carte, ax); hold on;
    plot3(chemin(:, 1), chemin(:, 2), chemin(:, 3), 'Color', [0.6 0.6 0.6]);
    plot3(points(:, 1), points(:, 2), points(:, 3), 'ko', 'MarkerFaceColor', 'y');
    plot3(res.r(:, 1), res.r(:, 2), res.r(:, 3), 'b', 'LineWidth', 1.5);
    legend('', '', '', '', '', '', '', '', 'A*', 'points de passage', 'drone');
    tracer_simulation(res, 'Suivi de la trajectoire planifiée');
    animer_drone(res, struct('echelle', 5, 'accel', 2, 'carte', carte));
end
