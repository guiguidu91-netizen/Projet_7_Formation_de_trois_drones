%% ÉTAPE 5 — Suivi de chemin 3D (TD question 8)
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();

%% 1. Point le plus proche sur le cercle de l'exemple 8.1(c)
R = 5;
cercle.gamma   = @(s) [ R*cos(s/R);  R*sin(s/R); 0];      % paramètre = abscisse curviligne
cercle.dgamma  = @(s) [-sin(s/R);    cos(s/R);   0];
cercle.d2gamma = @(s) [-cos(s/R)/R; -sin(s/R)/R; 0];
r = [6; 0; 0.5];
[r_T, t_hat, s_T, kappa, n_hat] = point_plus_proche(cercle, r, 1.0);
b_hat = cross(t_hat, n_hat);
d = r_T - r;
fprintf('\n--- 8.1(c) : drone en [6 0 0,5], recherche partie de s = 1 ---\n');
fprintf('s_T = %.4f, r_T = [%.3f %.3f %.3f], kappa = %.3f\n', s_T, r_T, kappa);
fprintf('t = [%.2f %.2f %.2f], n = [%.2f %.2f %.2f], b = [%.2f %.2f %.2f]\n', t_hat, n_hat, b_hat);
fprintf('d.t = %.1e (orthogonalité 8.1a)\n', d'*t_hat);

% 8.2(c) : point approché d'angle 0,1 rad
s_app = 0.1*R;
r_app = cercle.gamma(s_app);  t_app = cercle.dgamma(s_app);
d_app = r_app - r;
e_p = (eye(3) - t_app*t_app')*d_app;
fprintf('\n--- 8.2(c) : point approché (0,1 rad) ---\n');
fprintf('d = [%.3f %.3f %.3f], d.t = %.3f, e_p = [%.3f %.3f %.3f], |e_p| = %.3f (exact %.3f)\n', ...
        d_app, d_app'*t_app, e_p, norm(e_p), norm(d));

%% 2. Anticipation centripète sur l'hélice du TD (8.3d)
T = 12;
ref = traj_helice(T/2, 5, 2.5, T);
c = 2.5/(2*pi);
kappa_h = 5/(25 + c^2);
s_point = norm(ref.v);
[b3d, U1d] = poussee_desiree(ref.a, P);
fprintf('\n--- 8.3(d) : hélice à t = T/2 ---\n');
fprintf('kappa = %.3f, s_point = %.2f m/s, kappa s_point^2 = %.2f m/s^2, |a_ref| = %.2f m/s^2\n', ...
        kappa_h, s_point, kappa_h*s_point^2, norm(ref.a));
fprintf('inclinaison exacte = %.1f deg, U1d = %.2f mg, petits angles = %.1f deg\n', ...
        acosd(b3d(3)), U1d/(P.m*P.g), rad2deg(norm(ref.a(1:2))/P.g));

%% 3. Sans anticipation (8.3e)
G = gains_commande('td');
consigne = @(t) traj_helice(t, 5, 2.5, T);
G_sans = G;  G_sans.anticipation = false;
res_avec = simuler(P, G, consigne, @commande_geometrique, struct('duree', T + 2));
res_sans = simuler(P, G_sans, consigne, @commande_geometrique, struct('duree', T + 2));
k = round(T/2/1e-3) + 1;
radial = @(res) hypot(res.r(k, 1), res.r(k, 2)) - 5;
fprintf('\n--- 8.3(e) : écart radial à t = T/2 ---\n');
fprintf('avec anticipation : %+.3f m ; sans : %+.3f m (prévision kappa s^2 / kp = %.2f m)\n', ...
        radial(res_avec), radial(res_sans), kappa_h*s_point^2/G.kp(1));

%% 4. Trajectoire ou chemin (8.2d) : le drone part avec 3 s de retard sur l'horaire
% La consigne démarre à t = 3 s de l'horaire de l'hélice : le point de
% consigne est déjà 5 m devant le drone, qui est encore immobile au départ.
retard = 3;
consigne_r = @(t) traj_helice(t + retard, 5, 2.5, T);
G_traj = gains_commande('regle');
G_chem = G_traj;  G_chem.mode = 'chemin';
opts.duree = T + 2 - retard;
opts.X0 = etat_initial(traj_helice(0, 5, 2.5, T).r);
res_t = simuler(P, G_traj, consigne_r, @commande_geometrique, opts);
res_c = simuler(P, G_chem, consigne_r, @commande_geometrique, opts);
% distance réelle au chemin (et non à la consigne), un point sur 50
courbe = traj_helice(0, 5, 2.5, T).courbe;
dt_ = distance_au_chemin(courbe, res_t.r(1:50:end, :));
dc_ = distance_au_chemin(courbe, res_c.r(1:50:end, :));
fprintf('\n--- 8.2(d) : départ avec %g s de retard sur l''horaire ---\n', retard);
fprintf('%-18s %22s %22s\n', 'mode', 'distance max au chemin', 'écart final à la consigne');
fprintf('%-18s %20.3f m %20.3f m\n', 'trajectoire', max(dt_), norm(res_t.r(end, :) - res_t.r_ref(end, :)));
fprintf('%-18s %20.3f m %20.3f m\n', 'chemin', max(dc_), norm(res_c.r(end, :) - res_c.r_ref(end, :)));

if ~MODE_TEST
    figure('Name', 'Étape 5 - trajectoire ou chemin', 'Color', 'w');
    plot3(res_t.r_ref(:, 1), res_t.r_ref(:, 2), res_t.r_ref(:, 3), 'k--'); hold on;
    plot3(res_t.r(:, 1), res_t.r(:, 2), res_t.r(:, 3), 'b', 'LineWidth', 1.3);
    plot3(res_c.r(:, 1), res_c.r(:, 2), res_c.r(:, 3), 'r', 'LineWidth', 1.3);
    axis equal; grid on; view(3); legend('hélice', 'mode trajectoire', 'mode chemin');
    figure('Name', 'Étape 5 - anticipation', 'Color', 'w');
    plot(res_avec.r(:, 1), res_avec.r(:, 2), 'b', res_sans.r(:, 1), res_sans.r(:, 2), 'r', ...
         res_avec.r_ref(:, 1), res_avec.r_ref(:, 2), 'k--', 'LineWidth', 1.2);
    axis equal; grid on; legend('avec a_{ref}', 'sans a_{ref}', 'consigne'); xlabel('x'); ylabel('y');
end

function d = distance_au_chemin(courbe, r)
% distance de chaque position (lignes de r) au point le plus proche de la courbe
beta = unwrap(atan2(r(:, 2), r(:, 1)));      % bon tour de l'hélice comme départ
d = zeros(size(r, 1), 1);
for i = 1:size(r, 1)
    r_T = point_plus_proche(courbe, r(i, :)', beta(i));
    d(i) = norm(r_T - r(i, :)');
end
end
