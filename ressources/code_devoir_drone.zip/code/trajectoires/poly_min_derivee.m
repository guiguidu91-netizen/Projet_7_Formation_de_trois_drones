function C = poly_min_derivee(W, durees, k)
%POLY_MIN_DERIVEE  Polynômes par morceaux qui minimisent l'intégrale de |x^(k)|^2.
%
%   C = poly_min_derivee(W, durees, k)
%   W      : valeurs aux P = n+1 points de passage (une seule coordonnée)
%   durees : durées des n segments (s)
%   k      : ordre de la dérivée minimisée
%            k = 1 vitesse       -> segments de droite   (degré 1)
%            k = 2 accélération  -> degré 3
%            k = 3 jerk          -> degré 5
%            k = 4 snap          -> degré 7
%   C : matrice n x 2k, ligne i = [c0 c1 ... c_(2k-1)] du segment i, écrit
%       en temps local tau = t - t_i (tau de 0 à durees(i)).
%
%   Le polynôme optimal est de degré 2k-1 sur chaque segment : il a 2k
%   coefficients, donc il faut 2k conditions par segment :
%     - passage par les deux points du segment                (2n conditions)
%     - dérivées 1..k-1 nulles au départ et à l'arrivée       (2(k-1))
%     - continuité des dérivées 1..2k-2 aux points intérieurs  ((n-1)(2k-2))
%   Total 2kn : le système linéaire A c = b est carré.
%   Le temps est réel (pas normalisé) : les dérivées restent continues même
%   si les segments n'ont pas la même durée.

W = W(:);  durees = durees(:)';
n = numel(durees);
N = 2*k;
A = zeros(N*n, N*n);
b = zeros(N*n, 1);
ligne = 1;
% passage par les points
for i = 1:n
    col = N*(i-1)+1 : N*i;
    A(ligne, col) = poly_ligne(N, 0, 0);          b(ligne) = W(i);    ligne = ligne + 1;
    A(ligne, col) = poly_ligne(N, 0, durees(i));  b(ligne) = W(i+1);  ligne = ligne + 1;
end
% départ et arrivée au repos
for j = 1:k-1
    A(ligne, 1:N) = poly_ligne(N, j, 0);                       ligne = ligne + 1;
    A(ligne, N*(n-1)+1:N*n) = poly_ligne(N, j, durees(n));     ligne = ligne + 1;
end
% continuité aux points intérieurs
for i = 1:n-1
    for j = 1:2*k-2
        A(ligne, N*(i-1)+1:N*(i+1)) = [poly_ligne(N, j, durees(i)), -poly_ligne(N, j, 0)];
        ligne = ligne + 1;
    end
end
C = reshape(A\b, N, n)';
end
