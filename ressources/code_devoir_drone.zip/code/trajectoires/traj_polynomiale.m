function traj = traj_polynomiale(W, durees, k)
%TRAJ_POLYNOMIALE  Trajectoire 3D par points de passage, minimum de |x^(k)|^2.
%
%   traj = traj_polynomiale(W, durees, k)
%   W      : P x 3, points de passage (une ligne par point)
%   durees : durées des P-1 segments
%   k      : 2 (min. accélération), 3 (min. jerk), 4 (min. snap)
%   La trajectoire s'évalue ensuite avec eval_traj_polynomiale(traj, t).
%   Chaque coordonnée x, y, z est traitée séparément par poly_min_derivee.

traj.W = W;
traj.durees = durees(:)';
traj.temps  = [0, cumsum(traj.durees)];     % instants de passage
traj.k = k;
traj.C = cell(1, 3);
for ax = 1:3
    traj.C{ax} = poly_min_derivee(W(:, ax), durees, k);
end
end
