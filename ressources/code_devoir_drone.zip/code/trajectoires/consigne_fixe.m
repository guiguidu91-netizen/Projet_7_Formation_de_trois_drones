function ref = consigne_fixe(r, psi)
%CONSIGNE_FIXE  Consigne immobile en r avec le lacet psi (structure de référence).
%
%   Toutes les fonctions de trajectoire renvoient la même structure :
%       ref.r, ref.v, ref.a, ref.j   position, vitesse, accélération, jerk (R_o)
%       ref.psi, ref.dpsi            lacet désiré et sa dérivée
if nargin < 2, psi = 0; end
ref.r = r(:);  ref.v = zeros(3,1);  ref.a = zeros(3,1);  ref.j = zeros(3,1);
ref.psi = psi; ref.dpsi = 0;
end
