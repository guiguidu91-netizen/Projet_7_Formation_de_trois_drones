function ref = eval_traj_polynomiale(traj, t)
%EVAL_TRAJ_POLYNOMIALE  Consigne à l'instant t d'une trajectoire de traj_polynomiale.
%   ref.r, ref.v, ref.a, ref.j (lacet nul). Avant 0 et après la fin, la
%   consigne reste au premier ou au dernier point.
T_fin = traj.temps(end);
tc = min(max(t, 0), T_fin);
i  = find(tc >= traj.temps(1:end-1), 1, 'last');
tau = tc - traj.temps(i);
N = 2*traj.k;
D = zeros(4, 3);                          % lignes : dérivées 0 à 3
for ax = 1:3
    c = traj.C{ax}(i, :)';
    for j = 0:3
        D(j+1, ax) = poly_ligne(N, j, tau)*c;
    end
end
ref.r = D(1, :)';
ref.v = D(2, :)';  ref.a = D(3, :)';  ref.j = D(4, :)';
if t < 0 || t > T_fin
    ref.v = zeros(3,1);  ref.a = zeros(3,1);  ref.j = zeros(3,1);
end
ref.psi = 0;  ref.dpsi = 0;
end
