function L = poly_ligne(N, j, t)
%POLY_LIGNE  Ligne de la dérivée j-ième des monômes [1 t t^2 ... t^(N-1)].
%   p(t) = c0 + c1 t + ... + c_(N-1) t^(N-1)  =>  p^(j)(t) = poly_ligne(N, j, t) * c
%   Exemple : poly_ligne(4, 1, t) = [0 1 2t 3t^2].
L = zeros(1, N);
for n = j:N-1
    L(n+1) = prod(n-j+1:n) * t^(n-j);
end
end
