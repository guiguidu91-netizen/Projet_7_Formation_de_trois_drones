function ref = traj_echelon(t, r0, r1, t_saut, psi1)
%TRAJ_ECHELON  Échelon de position (et éventuellement de lacet) à t = t_saut.
%
%   ref = traj_echelon(t, r0, r1, t_saut)          lacet nul
%   ref = traj_echelon(t, r0, r1, t_saut, psi1)    échelon de lacet vers psi1
%   Sert à régler la cascade (question 5) : la consigne saute, les termes
%   d'anticipation sont nuls.
if nargin < 5, psi1 = 0; end
if t < t_saut
    ref = consigne_fixe(r0, 0);
else
    ref = consigne_fixe(r1, psi1);
end
end
