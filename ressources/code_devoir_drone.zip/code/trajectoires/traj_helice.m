function ref = traj_helice(t, rayon, montee, T)
%TRAJ_HELICE  Hélice du TD 8.3(d) : un tour en T secondes.
%
%   ref = traj_helice(t, rayon, montee, T)     (TD : rayon 5 m, montée 2,5 m, T = 12 s)
%
%   Courbe   gamma(beta) = [rayon cos(beta); rayon sin(beta); c beta],  c = montee/(2 pi)
%   Horaire  beta(t) quintique de 0 à 2 pi (vitesse et accélération nulles
%            au départ et à l'arrivée), vitesse max 1,875 x 2 pi / T à t = T/2.
%   En plus des champs habituels, ref contient la courbe (ref.courbe) et
%   le paramètre courant (ref.beta), utilisés en mode « chemin » (question 8).

c   = montee/(2*pi);
tau = min(max(t/T, 0), 1);
% profil quintique s(tau) = 10 tau^3 - 15 tau^4 + 6 tau^5 et ses dérivées
s   = 10*tau^3 - 15*tau^4 + 6*tau^5;
ds  = (30*tau^2 - 60*tau^3 + 30*tau^4)/T;
d2s = (60*tau - 180*tau^2 + 120*tau^3)/T^2;
d3s = (60 - 360*tau + 360*tau^2)/T^3;
if t > T, ds = 0; d2s = 0; d3s = 0; end
beta = 2*pi*s;  db = 2*pi*ds;  d2b = 2*pi*d2s;  d3b = 2*pi*d3s;

courbe.gamma   = @(b) [ rayon*cos(b);  rayon*sin(b); c*b];
courbe.dgamma  = @(b) [-rayon*sin(b);  rayon*cos(b); c  ];
courbe.d2gamma = @(b) [-rayon*cos(b); -rayon*sin(b); 0  ];
d3gamma        =      [ rayon*sin(beta); -rayon*cos(beta); 0];

g1 = courbe.dgamma(beta);  g2 = courbe.d2gamma(beta);
ref.r = courbe.gamma(beta);
ref.v = g1*db;
ref.a = g2*db^2 + g1*d2b;
ref.j = d3gamma*db^3 + 3*g2*db*d2b + g1*d3b;
ref.psi = 0;  ref.dpsi = 0;
ref.courbe = courbe;
ref.beta = beta;
end
