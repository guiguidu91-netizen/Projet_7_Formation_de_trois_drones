function G = gains_commande(jeu)
%GAINS_COMMANDE  Gains et options des lois de commande (TD questions 5, 7, 8).
%
%   G = gains_commande('td')      gains de la question 5.4(b)
%   G = gains_commande('amorti')  même kp d'attitude, kd porté à zeta = 0,7 (corrigé 5.4)
%   G = gains_commande('regle')   boucles réglées à l'étape 2 : position zeta = 0,7,
%                                 attitude wn = 30 rad/s, zeta = 0,7
%
%   Position (forme PD, une valeur par axe x, y, z) :
%       a_c = a_ref + kd.*e_v + kp.*e + ki.*integrale(e)
%       (équivaut à la cascade P-P de la question 5.4 avec k_v = kd, k_r = kp/kd)
%   Attitude (roulis, tangage, lacet) :
%       d2(phi)/dt2 = kp_att*(phi_d - phi) - kd_att*w_x   (idem tangage, lacet)
%       wn = sqrt(kp), zeta = kd/(2 sqrt(kp))  pour chaque boucle.

if nargin < 1, jeu = 'td'; end

% --- boucle de position (question 5.4b) ---
G.kp = [6; 6; 120];
G.kd = [2; 2; 16];
G.ki = [0; 0; 0];              % terme intégral, nul par défaut
G.integrale_max = 2;           % borne de l'intégrale (anti-emballement), m.s

% --- boucle d'attitude (question 5.4b) ---
G.kp_att = [260; 115; 115];
G.kd_att = [2.8; 2.8; 2.2];
switch lower(jeu)
    case 'td'
    case 'amorti'
        G.kd_att = 2*0.7*sqrt(G.kp_att);     % corrigé 5.4 : environ 22, 15, 15
    case 'regle'
        G.kd     = [3.4; 3.4; 16];            % zeta = 0,7 aussi en x, y
        G.kp_att = [900; 900; 115];           % wn = 30 rad/s en roulis et tangage
        G.kd_att = [42; 42; 15];              % zeta = 0,7 partout
    otherwise
        error('gains_commande:jeu', 'Jeu de gains inconnu : %s', jeu);
end

% --- options ---
G.angle_max = 35*pi/180;       % saturation de phi_d, theta_d (corrigé 5.3)
G.compense_inclinaison = true; % U1 = m(g+a_zc)/(cos(phi)cos(theta)) (corrigé 5.1)
G.anticipation = true;         % termes a_ref (8.3e) et jerk (8.4b)
G.mode = 'trajectoire';        % 'trajectoire' ou 'chemin' (question 8.2)
end
