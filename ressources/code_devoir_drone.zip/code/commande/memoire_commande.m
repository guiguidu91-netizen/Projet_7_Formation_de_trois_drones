function mem = memoire_commande()
%MEMOIRE_COMMANDE  Variables internes des correcteurs (état initial).
%   mem.int_e  : intégrale de l'erreur de position
%   mem.beta_T : paramètre du point le plus proche au pas précédent
mem.int_e = zeros(3,1);
mem.beta_T = NaN;          % dernier point le plus proche (mode chemin)
end
