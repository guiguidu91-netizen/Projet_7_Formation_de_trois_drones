function [e_R, e_w, Psi] = erreur_attitude(R, R_d, w, w_d)
%ERREUR_ATTITUDE  Erreurs d'attitude et de vitesse angulaire sur SO(3) (TD 7.5).
%
%   [e_R, e_w, Psi] = erreur_attitude(R, R_d, w, w_d)
%       Psi = 1/2 tr(I3 - R_d' R)                      (= 1 - cos(alpha))
%       e_R = 1/2 (R_d' R - R' R_d)^vee                (= sin(alpha) u)
%       e_w = w - R' R_d w_d
%   R : attitude réelle R_o^b, R_d : attitude désirée,
%   w : vitesse angulaire réelle (dans R_b), w_d : désirée (dans le repère désiré).

Psi = 0.5*trace(eye(3) - R_d'*R);
e_R = 0.5*vee(R_d'*R - R'*R_d);
e_w = w - R'*R_d*w_d;
end
