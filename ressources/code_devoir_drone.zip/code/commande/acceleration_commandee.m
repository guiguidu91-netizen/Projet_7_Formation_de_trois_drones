function [a_c, info, mem] = acceleration_commandee(etat, ref, G, mem, dt)
%ACCELERATION_COMMANDEE  Boucle externe : accélération commandée a_c (TD 5.4, 8.3).
%
%   [a_c, info, mem] = acceleration_commandee(etat, ref, G, mem, dt)
%
%   Loi PD avec anticipation (corrigé 8.3a), plus un terme intégral optionnel :
%       a_c = a_ref + Kd e_v + Kp e + Ki integrale(e)
%   avec e = r_ref - r et e_v = v_ref - r_point.
%
%   Mode 'chemin' (questions 8.2 et 8.3) : on ne compare plus le drone au
%   point de consigne de l'instant t mais au point le plus proche r_T de la
%   courbe. Erreur de position projetée sur le plan normal :
%       e_p = P_perp (r_T - r),   P_perp = I3 - t t'
%   Consigne en r_T, décomposée dans le trièdre de Frenet (corrigé 8.3c) :
%       r_T point  = s_point t
%       r_T 2point = s_2point t + kappa s_point^2 n
%   La vitesse d'avancement s_point est celle que prévoit l'horaire à t.
%   Être en retard le long de la courbe n'est donc pas une erreur (8.2d).

if strcmpi(G.mode, 'chemin') && isfield(ref, 'courbe')
    if isnan(mem.beta_T)               % premier appel : recherche grossière autour de la consigne
        mem.beta_T = ref.beta + linspace(-pi, pi, 181);
    end
    [r_T, t_hat, beta_T, kappa, n_hat] = point_plus_proche(ref.courbe, etat.r, mem.beta_T);
    mem.beta_T = beta_T;
    s_p  = norm(ref.v);
    s_pp = (ref.v'*ref.a)/max(s_p, 1e-6);
    v_T  = s_p*t_hat;
    a_T  = s_pp*t_hat + kappa*s_p^2*n_hat;
    e    = (eye(3) - t_hat*t_hat')*(r_T - etat.r);
    e_v  = v_T - etat.dr;
    info.r_T = r_T;
else
    a_T  = ref.a;
    e    = ref.r - etat.r;
    e_v  = ref.v - etat.dr;
    info.r_T = ref.r;
end

% intégrale bornée (anti-emballement)
mem.int_e = mem.int_e + e*dt;
mem.int_e = max(min(mem.int_e, G.integrale_max), -G.integrale_max);

if G.anticipation
    a_ref = a_T;
else
    a_ref = zeros(3,1);
end
a_c = a_ref + G.kd.*e_v + G.kp.*e + G.ki.*mem.int_e;

info.e   = e;
info.e_v = e_v;
info.a_c = a_c;
end
