function [b3d, U1d, F_Tc] = poussee_desiree(a_c, P)
%POUSSEE_DESIREE  De l'accélération commandée à l'axe de poussée (TD 7.3).
%
%   [b3d, U1d, F_Tc] = poussee_desiree(a_c, P)
%       F_Tc = m (a_c - g^o)          force de poussée à produire (dans R_o)
%       U1d  = ||F_Tc||               poussée désirée
%       b3d  = F_Tc / ||F_Tc||        direction que doit prendre k_b
%   L'estimation de traînée est prise nulle. La construction n'est pas
%   définie si a_c = g^o (chute libre demandée, corrigé 7.3g).

g_o  = [0; 0; -P.g];
F_Tc = P.m*(a_c(:) - g_o);
U1d  = norm(F_Tc);
if U1d < 1e-9
    error('poussee_desiree:chute_libre', 'a_c = g : aucune direction de poussée.');
end
b3d = F_Tc/U1d;
end
