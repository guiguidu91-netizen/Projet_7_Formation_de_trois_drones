function [R_d, b1d, b2d, c1d] = attitude_desiree(b3d, psi_d)
%ATTITUDE_DESIREE  Matrice d'attitude désirée R_d (TD 7.4).
%
%   [R_d, b1d, b2d, c1d] = attitude_desiree(b3d, psi_d)
%       c1d = [cos psi_d; sin psi_d; 0]           direction de lacet horizontale
%       b2d = (b3d ^ c1d) / ||b3d ^ c1d||
%       b1d = b2d ^ b3d                           (= projection de c1d sur le
%                                                  plan normal à b3d, 7.4c)
%       R_d = [b1d b2d b3d]
%   Singularité : b3d parallèle à c1d (drone « sur la tranche », 7.4f).

c1d = [cos(psi_d); sin(psi_d); 0];
n = cross(b3d, c1d);
if norm(n) < 1e-6
    error('attitude_desiree:singularite', 'b3d parallèle à c1d : cap non défini.');
end
b2d = n/norm(n);
b1d = cross(b2d, b3d);
R_d = [b1d, b2d, b3d];
end
