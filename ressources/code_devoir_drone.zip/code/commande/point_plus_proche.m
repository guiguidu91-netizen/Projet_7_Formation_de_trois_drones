function [r_T, t_hat, beta_T, kappa, n_hat] = point_plus_proche(courbe, r, beta0)
%POINT_PLUS_PROCHE  Point de la courbe le plus proche du drone (TD 8.1).
%
%   [r_T, t_hat, beta_T, kappa, n_hat] = point_plus_proche(courbe, r, beta0)
%   courbe : structure de fonctions du paramètre beta
%       courbe.gamma(beta), courbe.dgamma(beta), courbe.d2gamma(beta)
%   r      : position du drone
%   beta0  : point de départ de la recherche (le point trouvé au pas
%            précédent). Si beta0 est un vecteur, on garde d'abord la
%            valeur de beta0 la plus proche du drone (recherche grossière).
%
%   On annule phi'(beta) = (gamma(beta) - r).gamma'(beta) (condition 8.1a)
%   par la méthode de Newton, avec phi'' = |gamma'|^2 + (gamma - r).gamma''.
%   Le paramètre beta n'est pas forcément l'abscisse curviligne : la
%   condition d'orthogonalité est la même.
%   Sorties : r_T = gamma(beta_T), tangente t_hat, courbure kappa, normale n_hat.

if numel(beta0) > 1
    d2 = arrayfun(@(b) norm(courbe.gamma(b) - r), beta0);
    [~, i0] = min(d2);
    beta = beta0(i0);
else
    beta = beta0;
end
for it = 1:15
    g  = courbe.gamma(beta) - r;
    d1 = courbe.dgamma(beta);
    d2 = courbe.d2gamma(beta);
    f1 = g'*d1;
    f2 = d1'*d1 + g'*d2;
    if f2 <= 0, break; end             % on n'est plus dans un creux (8.1b)
    pas  = f1/f2;
    beta = beta - pas;
    if abs(pas) < 1e-10, break; end
end
beta_T = beta;
r_T = courbe.gamma(beta);
d1  = courbe.dgamma(beta);
d2  = courbe.d2gamma(beta);
t_hat = d1/norm(d1);
b = cross(d1, d2);
kappa = norm(b)/norm(d1)^3;
if norm(b) > 1e-12
    n_hat = cross(b/norm(b), t_hat);
else
    n_hat = zeros(3,1);                % portion droite : normale non définie (8.2e)
end
end
