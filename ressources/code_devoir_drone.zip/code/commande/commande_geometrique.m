function [U, info, mem] = commande_geometrique(etat, ref, P, G, mem, dt)
%COMMANDE_GEOMETRIQUE  Commande géométrique sur SE(3) (TD questions 7 et 8.4).
%
%   [U, info, mem] = commande_geometrique(etat, ref, P, G, mem, dt)
%   Même entrée et même sortie que commande_cascade : on peut échanger les
%   deux lois sans rien changer d'autre.
%
%   Les cinq étapes du corrigé 8.4(a) :
%     (i)   a_c = a_ref + Kd e_v + Kp e                       acceleration_commandee
%     (ii)  F_Tc = m(a_c - g), b3d, U1d                       poussee_desiree
%     (iii) R_d = [b1d b2d b3d] avec le cap psi_d             attitude_desiree
%     (iv)  w_d, e_R, e_w puis M_d                            erreur_attitude + loi 7.5(f)
%     (v)   mélangeur inverse                                 (fait par simuler.m)
%   Gains : K_R = J diag(kp_att), K_w = J diag(kd_att) (corrigé 7.5f), si
%   bien qu'au hover cette loi redonne exactement la cascade de la question 5.

% (i)
[a_c, info, mem] = acceleration_commandee(etat, ref, G, mem, dt);
% (ii)
[b3d, U1d, F_Tc] = poussee_desiree(a_c, P);
% (iii)
[R_d, b1d, b2d] = attitude_desiree(b3d, ref.psi);

% (iv) vitesse angulaire désirée, à partir du jerk (corrigé 8.4b).
%      Le terme dw_d/dt (qui demanderait le snap) est négligé.
if G.anticipation && isfield(ref, 'j')
    jerk = ref.j;
else
    jerk = zeros(3,1);
end
w_d = [ -P.m/U1d*dot(b2d, jerk) ;
         P.m/U1d*dot(b1d, jerk) ;
         ref.dpsi*b3d(3) ];

[e_R, e_w, Psi] = erreur_attitude(etat.R, R_d, etat.w, w_d);

w   = etat.w;
w_r = etat.R'*R_d*w_d;                       % w_d ramené dans R_b
K_R = P.J*diag(G.kp_att);
K_w = P.J*diag(G.kd_att);
M_d = -K_R*e_R - K_w*e_w + cross(w, P.J*w) - P.J*(antisym(w)*w_r);

% poussée appliquée : projection de F_Tc sur l'axe réel k_b (corrigé 7.3g)
U1 = max(dot(F_Tc, etat.R(:,3)), 0);

U = [U1; M_d];
info.R_d   = R_d;
info.eps_d = angles_zyx(R_d);
info.w_d   = w_d;
info.e_R   = e_R;
info.Psi   = Psi;
info.U1d   = U1d;
end
