function [U, info, mem] = commande_cascade(etat, ref, P, G, mem, dt)
%COMMANDE_CASCADE  Commande en cascade « petits angles » (TD question 5).
%
%   [U, info, mem] = commande_cascade(etat, ref, P, G, mem, dt)
%   Sortie : U = [U1; U2; U3; U4] = [T; Mx; My; Mz], à envoyer au mélangeur.
%
%   Chaîne (figure du corrigé 5.1) :
%     1. position/vitesse -> a_c                        (acceleration_commandee)
%     2. a_c, psi_d -> phi_d, theta_d (petits angles)   (question 5.3)
%     3. altitude : U1 = m (g + a_zc)                   (question 5.2)
%     4. attitude P -> w_d, puis vitesse angulaire -> M_d   (question 5.2)

% --- 1. boucle externe ---
[a_c, info, mem] = acceleration_commandee(etat, ref, G, mem, dt);

% --- 2. angles de référence (corrigé 5.3) ---
psi_d   = ref.psi;
phi_d   = (a_c(1)*sin(psi_d) - a_c(2)*cos(psi_d))/P.g;
theta_d = (a_c(1)*cos(psi_d) + a_c(2)*sin(psi_d))/P.g;
phi_d   = max(min(phi_d,   G.angle_max), -G.angle_max);
theta_d = max(min(theta_d, G.angle_max), -G.angle_max);

% --- 3. altitude ---
phi = etat.eps(1);  theta = etat.eps(2);  psi = etat.eps(3);
U1 = P.m*(P.g + a_c(3));
if G.compense_inclinaison
    U1 = U1/max(cos(phi)*cos(theta), 0.5);   % on garde la même poussée verticale
end

% --- 4. attitude puis vitesse angulaire (cascade P - P) ---
e_R = [phi_d - phi; theta_d - theta; angle_principal(psi_d - psi)];
w_d = (G.kp_att./G.kd_att).*e_R + [0; 0; ref.dpsi];          % boucle d'attitude
M_d = P.J*(G.kd_att.*(w_d - etat.w)) + cross(etat.w, P.J*etat.w); % boucle de vitesse angulaire

U = [U1; M_d];
info.eps_d = [phi_d; theta_d; psi_d];
info.w_d   = w_d;
end
