%% ÉTAPE 4 — Géométrie SE(3), attitude désirée et commande géométrique (TD question 7)
if ~exist('MODE_TEST', 'var'), MODE_TEST = false; end
P = parametres_drone();
deg = 180/pi;

%% 1. Applications numériques du TD, calculées par les fonctions du code
fprintf('\n--- 7.3 : de a_c à b3d ---\n');
for a_c = {[1; 0; 0], [P.g; 0; 0]}
    [b3d, U1d, F_Tc] = poussee_desiree(a_c{1}, P);
    fprintf('a_c = [%.2f 0 0] : F_Tc = [%.3f %.3f %.3f] N, U1d = %.3f N = %.3f mg, beta = %.2f deg\n', ...
            a_c{1}(1), F_Tc, U1d, U1d/(P.m*P.g), acosd(b3d(3)));
end

fprintf('\n--- 7.4(d) : R_d pour a_c = [g 0 0], psi_d = 30 deg ---\n');
[b3d, U1d] = poussee_desiree([P.g; 0; 0], P);
[R_d, b1d, b2d, c1d] = attitude_desiree(b3d, 30/deg);
disp(R_d);
fprintf('R_d''R_d - I : %.1e   det R_d = %.4f\n', norm(R_d'*R_d - eye(3)), det(R_d));
b1_proj = (eye(3) - b3d*b3d')*c1d;  b1_proj = b1_proj/norm(b1_proj);
fprintf('b1d par le projecteur (7.4c) : écart %.1e\n', norm(b1_proj - b1d));
eps_d = angles_zyx(R_d)*deg;
phi_pa   = (P.g*sind(30))/P.g*deg;          % petits angles (5.3) avec a_c = [g 0 0]
theta_pa = (P.g*cosd(30))/P.g*deg;
fprintf('Angles Z-Y-X de R_d : phi = %.1f, theta = %.1f, psi = %.1f deg\n', eps_d);
fprintf('Petits angles (5.3)  : phi = %.1f, theta = %.1f, psi = 30 deg\n', phi_pa, theta_pa);

fprintf('\n--- 7.5 : erreur d''attitude ---\n');
fprintf('%8s %10s %10s\n', 'alpha', '|e_R|', 'Psi');
for alpha = [10 30 90 150 180]
    Rx = rotation_zyx(alpha/deg, 0, 0);
    [e_R, ~, Psi] = erreur_attitude(Rx, eye(3), zeros(3,1), zeros(3,1));
    fprintf('%7.0f° %10.3f %10.3f\n', alpha, norm(e_R), Psi);
end
[e_R, ~, Psi] = erreur_attitude(eye(3), R_d, zeros(3,1), zeros(3,1));
fprintf('Drone à plat, R_d de 7.4(d) : e_R = [%.3f %.3f %.3f], |e_R| = %.3f, alpha = %.1f deg\n', ...
        e_R, norm(e_R), acosd(1 - Psi));

%% 2. Cascade petits angles contre commande géométrique sur l'hélice
G = gains_commande('td');
fprintf('\n--- Hélice r = 5 m, montée 2,5 m, un tour en T secondes (gains TD) ---\n');
fprintf('%5s | %-30s | %-30s\n', 'T', 'cascade (question 5)', 'géométrique (question 7)');
fprintf('%5s | %9s %9s %9s | %9s %9s %9s\n', '(s)', 'err max', 'incl.', 'état', 'err max', 'incl.', 'état');
lois = {@commande_cascade, @commande_geometrique};
for T = [12 10 9 8]
    consigne = @(t) traj_helice(t, 5, 2.5, T);
    ligne = sprintf('%5.0f |', T);
    for l = 1:2
        res = simuler(P, G, consigne, lois{l}, struct('duree', T + 2));
        if res.diverge, etat_txt = 'diverge'; else, etat_txt = 'ok'; end
        ligne = [ligne, sprintf(' %8.3f %8.1f° %9s |', res.erreur_max, res.inclinaison_max, etat_txt)]; %#ok<AGROW>
        if T == 12 && l == 2, res_12 = res; end
    end
    fprintf('%s\n', ligne);
end

% Même hélice à T = 8 s, mais avec les gains réglés à l'étape 2
G_rg = gains_commande('regle');
consigne = @(t) traj_helice(t, 5, 2.5, 8);
fprintf('\nT = 8 s avec les gains réglés :\n');
noms_lois = {'cascade', 'géométrique'};
for l = 1:2
    res = simuler(P, G_rg, consigne, lois{l}, struct('duree', 10));
    if res.diverge, etat_txt = 'diverge'; else, etat_txt = 'ok'; end
    fprintf('  %-12s erreur max %.3f m, inclinaison max %.1f deg, %s\n', noms_lois{l}, ...
            res.erreur_max, res.inclinaison_max, etat_txt);
end
% Inclinaison exacte demandée au milieu de l'hélice, pour chaque durée (7.3e)
fprintf('\nInclinaison demandée à t = T/2 :');
for T = [12 10 9 8]
    ref = traj_helice(T/2, 5, 2.5, T);
    b3d = poussee_desiree(ref.a, P);
    fprintf('  T = %2d s : %.1f deg', T, acosd(b3d(3)));
end
fprintf('\n');

if ~MODE_TEST
    tracer_simulation(res_12, 'Hélice T = 12 s, commande géométrique');
    animer_drone(res_12, struct('echelle', 6, 'accel', 2));
end
