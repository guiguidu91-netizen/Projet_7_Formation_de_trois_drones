function a = angle_principal(a)
%ANGLE_PRINCIPAL  Ramène un angle (ou un écart d'angle) dans ]-pi, pi].
a = atan2(sin(a), cos(a));
end
