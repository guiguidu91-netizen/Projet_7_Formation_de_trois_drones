function eps = angles_zyx(R)
%ANGLES_ZYX  Angles [phi; theta; psi] (séquence Z-Y-X) d'une matrice R_o^b.
%   Formules du TD 7.4(e) :
%       theta = -asin(R31),  phi = atan2(R32, R33),  psi = atan2(R21, R11)
%   Singulier pour theta = +-90 deg (question 1.5) : on ne s'en sert que
%   pour l'affichage et pour la commande petits angles.
theta = -asin(max(-1, min(1, R(3,1))));
phi   = atan2(R(3,2), R(3,3));
psi   = atan2(R(2,1), R(1,1));
eps = [phi; theta; psi];
end
