function animer_drone(res, opts)
%ANIMER_DRONE  Animation 3D d'une simulation (drone X, rotors colorés).
%   animer_drone(res)
%   animer_drone(res, opts)  avec opts.echelle (défaut 4), opts.accel
%   (facteur de vitesse, défaut 1 = temps réel), opts.carte (carte de
%   planification à afficher).
if nargin < 2, opts = struct(); end
if ~isfield(opts, 'echelle'), opts.echelle = 4; end
if ~isfield(opts, 'accel'),   opts.accel = 1;   end
P = res.P;
fig = figure('Name', 'Animation', 'Color', 'w');
ax = axes(fig); hold(ax, 'on'); grid(ax, 'on'); axis(ax, 'equal'); view(ax, 35, 25);
xlabel(ax, 'x (m)'); ylabel(ax, 'y (m)'); zlabel(ax, 'z (m)');
if isfield(opts, 'carte'), tracer_carte(opts.carte, ax); end
plot3(ax, res.r_ref(:,1), res.r_ref(:,2), res.r_ref(:,3), 'k--');
trace = plot3(ax, nan, nan, nan, 'b', 'LineWidth', 1.5);
marge = 0.5 + 0.2*opts.echelle;
lim = [min(res.r) - marge; max(res.r) + marge];
axis(ax, [lim(1,1) lim(2,1) lim(1,2) lim(2,2) lim(1,3) lim(2,3)]);
h = dessiner_drone(ax, P, opts.echelle);
pas = max(1, round(0.04/(res.t(2) - res.t(1))));       % environ 25 images/s
tic;
for k = 1:pas:numel(res.t)
    if ~isvalid(fig), return; end
    R = rotation_zyx(res.eps(k,1), res.eps(k,2), res.eps(k,3));
    placer_drone(h, res.r(k,:), R, res.Omega(k,:), P);
    set(trace, 'XData', res.r(1:k,1), 'YData', res.r(1:k,2), 'ZData', res.r(1:k,3));
    title(ax, sprintf('t = %.2f s', res.t(k)));
    drawnow;
    attente = res.t(k)/opts.accel - toc;
    if attente > 0, pause(attente); end
end
end
