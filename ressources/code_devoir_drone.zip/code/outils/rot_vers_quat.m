function q = rot_vers_quat(R)
%ROT_VERS_QUAT  Quaternion unitaire q = [q0; q_v] d'une matrice de rotation.
%   Méthode de Shepperd : on part du plus grand terme pour éviter les
%   divisions par un nombre proche de zéro. On impose q0 >= 0 (q et -q
%   représentent la même rotation).
tr = trace(R);
if tr > max([R(1,1), R(2,2), R(3,3)])
    q0 = 0.5*sqrt(1 + tr);
    q  = [q0; (R(3,2)-R(2,3))/(4*q0); (R(1,3)-R(3,1))/(4*q0); (R(2,1)-R(1,2))/(4*q0)];
elseif R(1,1) >= R(2,2) && R(1,1) >= R(3,3)
    qx = 0.5*sqrt(1 + R(1,1) - R(2,2) - R(3,3));
    q  = [(R(3,2)-R(2,3))/(4*qx); qx; (R(1,2)+R(2,1))/(4*qx); (R(1,3)+R(3,1))/(4*qx)];
elseif R(2,2) >= R(3,3)
    qy = 0.5*sqrt(1 - R(1,1) + R(2,2) - R(3,3));
    q  = [(R(1,3)-R(3,1))/(4*qy); (R(1,2)+R(2,1))/(4*qy); qy; (R(2,3)+R(3,2))/(4*qy)];
else
    qz = 0.5*sqrt(1 - R(1,1) - R(2,2) + R(3,3));
    q  = [(R(2,1)-R(1,2))/(4*qz); (R(1,3)+R(3,1))/(4*qz); (R(2,3)+R(3,2))/(4*qz); qz];
end
if q(1) < 0, q = -q; end
q = q/norm(q);
end
