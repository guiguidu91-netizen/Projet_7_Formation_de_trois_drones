function h = dessiner_drone(ax, P, echelle)
%DESSINER_DRONE  Crée le dessin d'un quadrirotor X dans les axes ax.
%   h = dessiner_drone(ax, P, echelle)
%   Le dessin est attaché à un hgtransform h.T ; on le déplace avec
%   placer_drone(h, r, R, Omega, P). echelle grossit le drone pour qu'il
%   reste visible sur une scène de plusieurs mètres.
if nargin < 3, echelle = 1; end
h.T = hgtransform('Parent', ax);
rr = P.r_rotors*echelle;
rayon = 0.045*echelle;
ang = linspace(0, 2*pi, 25);
for i = 1:4
    line([0 rr(1,i)], [0 rr(2,i)], [0 0], 'Parent', h.T, 'Color', [0.3 0.3 0.3], 'LineWidth', 2);
    h.rotor(i) = patch(rr(1,i) + rayon*cos(ang), rr(2,i) + rayon*sin(ang), ...
        zeros(size(ang)), [0.6 0.6 0.6], 'Parent', h.T, 'FaceAlpha', 0.8, 'EdgeColor', 'k');
    text(rr(1,i), rr(2,i), 0.02*echelle, num2str(i), 'Parent', h.T, ...
        'HorizontalAlignment', 'center', 'FontWeight', 'bold');
end
% axe avant i_b en rouge, axe k_b (poussée) en bleu
line([0 0.12*echelle], [0 0], [0 0], 'Parent', h.T, 'Color', 'r', 'LineWidth', 2.5);
line([0 0], [0 0], [0 0.10*echelle], 'Parent', h.T, 'Color', 'b', 'LineWidth', 2);
end
