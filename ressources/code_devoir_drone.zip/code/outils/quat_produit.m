function p = quat_produit(q, r)
%QUAT_PRODUIT  Produit de deux quaternions p = q (x) r, avec q = [q0; q_v].
q0 = q(1); qv = q(2:4);
r0 = r(1); rv = r(2:4);
p = [ q0*r0 - qv'*rv ;
      q0*rv(:) + r0*qv(:) + cross(qv(:), rv(:)) ];
end
