function u = vee(S)
%VEE  Opérateur inverse de S(.) : vee(antisym(u)) = u (TD 7.5).
%   On prend la moyenne des deux termes symétriques, ce qui reste juste
%   même si S n'est pas parfaitement antisymétrique (erreurs d'arrondi).
u = 0.5*[ S(3,2) - S(2,3) ;
          S(1,3) - S(3,1) ;
          S(2,1) - S(1,2) ];
end
