function R = rotation_zyx(phi, theta, psi)
%ROTATION_ZYX  R_o^b = Rz(psi) Ry(theta) Rx(phi), séquence Z-Y-X du TD.
%   phi : roulis, theta : tangage, psi : lacet (rad).
cf = cos(phi);   sf = sin(phi);
ct = cos(theta); st = sin(theta);
cp = cos(psi);   sp = sin(psi);
R = [ cp*ct,  cp*st*sf - sp*cf,  cp*st*cf + sp*sf ;
      sp*ct,  sp*st*sf + cp*cf,  sp*st*cf - cp*sf ;
       -st ,       ct*sf      ,       ct*cf      ];
end
