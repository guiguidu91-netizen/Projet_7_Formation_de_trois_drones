function placer_drone(h, r, R, Omega, P)
%PLACER_DRONE  Déplace le dessin (dessiner_drone) et colore les rotors.
%   Rouge : rotor plus rapide qu'au hover ; bleu : plus lent.
M = eye(4);  M(1:3,1:3) = R;  M(1:3,4) = r(:);
set(h.T, 'Matrix', M);
Omega_h = sqrt(P.m*P.g/(4*P.kf));
for i = 1:4
    d = max(-1, min(1, (Omega(i) - Omega_h)/(0.25*Omega_h)));
    if d >= 0, c = [1, 1-d, 1-d]; else, c = [1+d, 1+d, 1]; end
    set(h.rotor(i), 'FaceColor', c);
end
end
