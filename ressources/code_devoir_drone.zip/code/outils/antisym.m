function S = antisym(u)
%ANTISYM  Matrice antisymétrique S(u) telle que S(u)*x = u ^ x.
%   S = antisym(u), u vecteur 3x1. Opérateur inverse : vee.m.
S = [  0    -u(3)   u(2) ;
      u(3)    0    -u(1) ;
     -u(2)   u(1)    0  ];
end
