function R = quat_vers_rot(q)
%QUAT_VERS_ROT  Matrice R_o^b d'un quaternion unitaire q = [q0; q_v] (corrigé 1.5c).
%   R = I3 + 2 q0 S(q_v) + 2 S(q_v)^2
q  = q(:)/norm(q);
Sq = antisym(q(2:4));
R  = eye(3) + 2*q(1)*Sq + 2*Sq*Sq;
end
