function fig = tracer_simulation(res, titre)
%TRACER_SIMULATION  Courbes d'une simulation : position, erreur, angles, rotors, 3D.
%   fig = tracer_simulation(res, titre)
if nargin < 2, titre = 'Simulation'; end
P = res.P;
Omega_h = sqrt(P.m*P.g/(4*P.kf));          % vitesse au hover (question 4.3)
t = res.t;
fig = figure('Name', titre, 'Color', 'w', 'Position', [80 80 1150 700]);
tl = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, titre, 'Interpreter', 'none');

noms = {'x', 'y', 'z'};
for i = 1:3
    ax = nexttile(tl);
    plot(ax, t, res.r_ref(:,i), 'k--', t, res.r(:,i), 'b', 'LineWidth', 1.2);
    grid(ax, 'on'); xlabel(ax, 't (s)'); ylabel(ax, [noms{i} ' (m)']);
    if i == 1, legend(ax, 'consigne', 'drone', 'Location', 'best'); end
end

ax = nexttile(tl);
plot(ax, t, rad2deg(res.eps(:,1)), 'r', t, rad2deg(res.eps(:,2)), 'b', ...
     t, rad2deg(res.eps(:,3)), 'g', 'LineWidth', 1.1); hold(ax, 'on');
plot(ax, t, rad2deg(res.eps_d(:,1)), 'r:', t, rad2deg(res.eps_d(:,2)), 'b:', 'LineWidth', 1);
grid(ax, 'on'); xlabel(ax, 't (s)'); ylabel(ax, 'angles (deg)');
legend(ax, '\phi', '\theta', '\psi', '\phi_d', '\theta_d', 'Location', 'best');

ax = nexttile(tl);
plot(ax, t, res.Omega, 'LineWidth', 1); hold(ax, 'on');
yline(ax, Omega_h, 'k--'); yline(ax, P.Omega_max, 'r--');
grid(ax, 'on'); xlabel(ax, 't (s)'); ylabel(ax, '\Omega_i (tr/min)');
legend(ax, '\Omega_1', '\Omega_2', '\Omega_3', '\Omega_4', 'hover', 'max', 'Location', 'best');

ax = nexttile(tl);
plot3(ax, res.r_ref(:,1), res.r_ref(:,2), res.r_ref(:,3), 'k--'); hold(ax, 'on');
plot3(ax, res.r(:,1), res.r(:,2), res.r(:,3), 'b', 'LineWidth', 1.3);
axis(ax, 'equal'); grid(ax, 'on'); view(ax, 3);
xlabel(ax, 'x'); ylabel(ax, 'y'); zlabel(ax, 'z');
title(ax, sprintf('erreur max %.3f m, inclinaison max %.1f deg', ...
      res.erreur_max, res.inclinaison_max));
end
